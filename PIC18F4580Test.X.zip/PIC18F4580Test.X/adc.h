/* 
 * File:   adc.h
 * Author: Nishanth
 *
 * Created on 20 July, 2014, 8:36 PM
 */




